$(function () {

    // 提交按钮
    $('#tijiao').on('click', function (evt) {
        var param = {};
        var _this = this;

        var old_card_psd = $("#old_card_psd").val();
        var old_card_code = $("#old_card_code").val();

        if('' === old_card_code) {
            $.mAlert("卡号不可为空！");
            return;
        }

        if('' === old_card_psd) {
            $.mAlert("原密码不可为空！");
            return;
        }

        param.password = $("#old_card_psd").val();
        param.cardno = $("#old_card_code").val();

        var new_card_psd1 = $('#new_card_psd1').val();
        var new_card_psd2 = $('#new_card_psd2').val();

        if('' === new_card_psd1) {
            $.mAlert("新密码不可为空！");
            return;
        }
        if('' === new_card_psd2) {
            $.mAlert("确认密码不可为空！");
            return;
        }
        if(new_card_psd1 != new_card_psd2) {
            $.mAlert("两次密码输入必须相同");
            return;
        }

        param.password = new_card_psd1;

        if (!param.password.isPassword()) {
            $.mAlert("密码错误");
            return;
        }

        $(_this).text("修改中...").prop('disabled', true);

        $.post("url", param, function (data) {
            $(_this).text("确定").prop('disabled', false);
            if(data.state === '000000') {
                // 修改成功，跳转页面
                window.location.href = 'url';
            } else {
                $.mAlert( data.msg );
            }
        })
    });

})