$(function () {

    // 验证账户
    $("#get_code").touchClick(function(){
        var old_mobile = $("#old_mobile").val();
        var new_mobile = $("#new_mobile").val();

        if (!new_mobile.isPhone()) {
            $.mAlert("请输入有效的手机号码");
            return;
        }

        if(old_mobile === new_mobile) {
            $.mAlert("新手机号不能和原手机号相同");
            return;
        }

        $("#get_code>button").dxlCountdown({
            firstText: "发送验证码",
            sendText: "重新发送",
            waitText: "s",
            mobile: $("#new_mobile"),
            sendAction: function() {
                sendCode($("#new_mobile").val(), $("#yzm"));
            },
            sendError: function() {
                $.mAlert("请输入有效的手机号码");
            }
        });
    });

    // 提交按钮
    $('#tijiao').on('click', function (evt) {
        var param = {};
        var _this = this;
        param.memberphone = $("#new_mobile").val();
        param.memberyzm = $("#yzm").val();

        if (!param.memberphone.isPhone()) {
            $.mAlert("请输入有效的手机号码");
            return;
        }

        if (!param.memberyzm || param.memberyzm.length != 6) {
            $.mAlert("验证码错误");
            return;
        }

        $(_this).text("申请中...").prop('disabled', true);

        $.post("http://localhost:8080/wechatcard/register", param, function (data) {
            $(_this).text("修改").prop('disabled', false);
            if(data.state === '000000') {
                // 注册成功，跳转页面
                window.location.href = '';
            } else {
                $.mAlert( data['msg'] );
            }
        })
    });

    // 发送短信验证码
    function sendCode(mobile, $focusDom) {
        var getCodeBtn = $("#get_code>button");
        getCodeBtn.prop('disabled', true);
        $.dxlSmsSend({
            mobile: mobile
        }, function (data) {
            if (data.code == 1) {
                $.mAlert("验证码已发送，请注意查收");
                $focusDom.focus();
                setTimeout(function() {
                    getCodeBtn.prop('disabled', false);
                }, 60 * 1000);
            } else {
                $.mAlert( data['msg'] );
            }
        });
    }


});