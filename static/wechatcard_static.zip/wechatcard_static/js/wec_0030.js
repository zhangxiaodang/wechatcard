$(function () {

    $("#old_card_bind").on('click', function (evt) {
        //
    })

});