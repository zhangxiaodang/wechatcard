$(function () {

    $("#old_card_bind").on('click', function (evt) {
        //
    });

    $.post('/get_card_coupon', function(data) {
        if(data.state === '000000') {
            var card_list = data['card_list'] || [];
            var coupon_list = data['coupon_list'] || [];
            var $ka = $("#ka").children();
            var $quan = $("#quan").children();
            var ka_html = '';
            var quan_html = '';
            var ka_len = card_list.length;
            var quan_len = coupon_list.length;

            if(ka_len) {
                for(var i = 0; i < ka_len; i++) {
                    ka_html += '<a href="#" class="list-group-item active" id="'+ ka_len[i]['merbercardid'] +'">' +
                        '<div>' +
                        '<img src="'+ ka_len[i]['merbercardimg'] +'" alt=""/>' +
                        '<h4 class="list-group-item-heading">'+ ka_len[i]['merchantname'] +'��Ա��ֵ��</h4>' +
                        '<p class="list-group-item-text">��ֵ��</p>' +
                        '</div>' +
                        '<em>��������Ա��ֵ������Աר���</em>' +
                    '</a>';
                }

                $ka.empty().append( ka_html );
            }

            if(quan_len) {
                for(var i = 0; i < quan_len; i++) {
                    quan_html += '<a href="#" class="list-group-item active" id="'+ quan_len[i]['couponid'] +'">' +
                        '<div>' +
                        '<img src="'+ quan_len[i]['couponimg'] +'" alt=""/>' +
                        '<h4 class="list-group-item-heading">'+ quan_len[i]['couponname'] +'</h4>' +
                        '<p class="list-group-item-text">'+ quan_len[i]['couponkssj'] +'��'+ quan_len[i]['couponjssj'] +'</p>' +
                        '</div>' +
                        '</a>';
                }

                $quan.empty().append( quan_html );
            }

        } else {
            $.mAlert( data['msg'] );
        }
    });

});