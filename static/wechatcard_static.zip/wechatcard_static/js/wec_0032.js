$(function () {

    // 提交按钮
    $('#tijiao').on('click', function (evt) {
        var param = {};
        var _this = this;

        var card_code = $("#card_code").val();
        var jiner = $("#jiner").val();
        
        if('' === card_code) {
            $.mAlert("卡号不可为空！");
            return;
        }

        if('' === jiner) {
            $.mAlert("金额不可为空！");
            return;
        }

        param.jiner = jiner;
        param.cardno = card_code;

        $(_this).text("申请中...").prop('disabled', true);

        $.post("http://localhost:8080/wechatcard/register", param, function (data) {
            $(_this).text("确定").prop('disabled', false);
            if(data.state === '000000') {
                // 注册成功，跳转页面
                window.location.href = '../html/wec_0010.html';
            } else {
                $.mAlert( data['msg'] );
            }
        })
    });


});