$(function () {

    // 清空列表
    //$('#list').empty();
    var pageNum = 1;

    function listPage() {
        $.post('', {
            page: pageNum,
            limit: 10
        }, function (data) {
            if(data.state == '000000') {
                $("#jzgd").text("加载更多").prop('disabled', false);
                pageNum = data.page;
                var dataList = data.list;
                var a = '';
                if(!dataList.length) {
                    $("#jzgd").hide().prev().show();
                    return false;
                }
                for(var i = 0, len = dataList.length; i < len; i++) {
                    a += '<a href="#" class="list-group-item active">'+
                    '<div>' +
                    '<img src="'+ dataList[i]['img'] +'" alt=""/>'+
                    '<h4 class="list-group-item-heading">'+ dataList[i]['img'] +'</h4>'+
                    '<p class="list-group-item-text">消费时间：'+ dataList[i]['time'] +'</p>'+
                    '<p class="list-group-item-text">消费门店：'+ dataList[i]['address'] +'</p>'+
                    '<p class="list-group-item-text">消费金额：￥'+ dataList[i]['price'] +'</p>'+
                    '</div>'+
                    '</a>';
                }
                $('#list').append( a );
            }
        });
    }

    listPage();

    // 点击加载更多
    $("#jzgd").on('click', function (evt) {
        $("#jzgd").text("加载中...").prop('disabled', true);
        listPage();
    });


});