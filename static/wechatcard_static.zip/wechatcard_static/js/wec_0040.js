$(function () {

    $('.list-group').on('click', 'a', function (evt) {
        evt.preventDefault();
        window.location.href = '';
    });

});