$(function () {

    // 领取优惠券
    $('#tijiao').on('click', function (evt) {
        // 优惠券id
        var yhq_id = '';

        $.post('url', { yhq_id: yhq_id }, function (data) {
            if(data.state === '000000') {
                // 领取完毕后，展示优惠券详情页0042
            } else {
                $.mAlert( data['msg'] );
            }
        })
    });

});